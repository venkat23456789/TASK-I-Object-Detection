calculate frame time
